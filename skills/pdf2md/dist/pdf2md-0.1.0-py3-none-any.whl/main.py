#!/usr/bin/env python3
"""CLI tool to convert PDF to Markdown using pymupdf4llm"""

import argparse
import contextlib
import io
import sys
from pathlib import Path

# Suppress pymupdf4llm layout suggestion printed on import
with contextlib.redirect_stdout(io.StringIO()):
    import pymupdf4llm


def convert_pdf_to_md(
    pdf_path: Path,
    output_path: Path | None = None,
    pages: list[int] | None = None,
    write_images: bool = False,
    image_path: str = "images",
) -> str:
    """
    Convert a PDF file to Markdown.

    Args:
        pdf_path: Path to the PDF file
        output_path: Optional path for the output markdown file
        pages: Optional list of page numbers to convert (0-indexed)
        write_images: Whether to extract and save images
        image_path: Directory for extracted images

    Returns:
        The markdown content as a string
    """
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    if not pdf_path.suffix.lower() == ".pdf":
        raise ValueError(f"File must be a PDF: {pdf_path}")

    # Convert PDF to markdown
    markdown_content = pymupdf4llm.to_markdown(
        str(pdf_path),
        pages=pages,
        write_images=write_images,
        image_path=image_path,
    )

    # Save to file if output path specified
    if output_path:
        output_path.write_text(markdown_content, encoding="utf-8")
        print(f"Saved to {output_path}", file=sys.stderr)

    return markdown_content


def parse_page_range(page_str: str) -> list[int]:
    """Parse page range string like '1-5,7,9-11' into list of page numbers (0-indexed)."""
    pages = []
    for part in page_str.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            pages.extend(range(int(start) - 1, int(end)))
        else:
            pages.append(int(part) - 1)
    return sorted(set(pages))


def main():
    parser = argparse.ArgumentParser(
        description="Convert PDF to Markdown",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pdf2md document.pdf                    # Output to stdout
  pdf2md document.pdf -o output.md       # Save to file
  pdf2md document.pdf -p 1-5             # Convert pages 1-5 only
  pdf2md document.pdf -p 1,3,5-7         # Convert specific pages
  pdf2md document.pdf --images           # Extract images too
        """,
    )
    parser.add_argument(
        "pdf_file",
        type=Path,
        help="Path to the PDF file to convert",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output markdown file path (default: print to stdout)",
    )
    parser.add_argument(
        "-p",
        "--pages",
        type=str,
        default=None,
        help="Page range to convert (e.g., '1-5' or '1,3,5-7'). Pages are 1-indexed.",
    )
    parser.add_argument(
        "--images",
        action="store_true",
        help="Extract and save images from the PDF",
    )
    parser.add_argument(
        "--image-path",
        type=str,
        default="images",
        help="Directory to save extracted images (default: images)",
    )

    args = parser.parse_args()

    try:
        pages = parse_page_range(args.pages) if args.pages else None

        markdown = convert_pdf_to_md(
            args.pdf_file,
            args.output,
            pages=pages,
            write_images=args.images,
            image_path=args.image_path,
        )

        # Print to stdout if no output file specified
        if not args.output:
            print(markdown)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
